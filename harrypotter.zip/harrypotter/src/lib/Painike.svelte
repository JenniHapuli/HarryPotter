<script>
    export let teksti = "Hae";
    export let klikkaa = () => {};
  </script>
  
  <button on:click={klikkaa} class="painike">
    {teksti}
  </button>
  
  <style>
    .painike {
      background-color: #d2c209;
      color: rgb(0, 0, 0);
      border: none;
      padding: 10px 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 1em;
      cursor: pointer;
      border-radius: 5px;
    }
  
    .painike:hover {
      background-color: #80740c;
    }
  </style>
  