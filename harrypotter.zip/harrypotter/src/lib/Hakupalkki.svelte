<script>
    import { createEventDispatcher } from "svelte";
    const dispatch = createEventDispatcher();
    let hakusana = ""; // Käyttäjän syöttämä hakusana
  
    // Lähettää "haku"-tapahtuman käyttäjän syötteen perusteella
    function hae() {
      dispatch("haku", hakusana);
    }
  </script>
  
  <div>
    <!-- Hakukenttä, joka kuuntelee käyttäjän syötettä ja käynnistää hakutoiminnon -->
    <input
      type="text"
      placeholder="Hae hahmoa nimellä"
      bind:value={hakusana}
      on:input={hae}
    />
  </div>
  
  <style>
    div {
      margin: 10px;
      display: flex;
    align-items: left;

    }
    input {
      padding: 8px;
      font-size: 16px;
      background-color: white;
      color: black;
      width: 300px;
      border-radius: 8px;
      margin-left: 1em;
    }
  </style>