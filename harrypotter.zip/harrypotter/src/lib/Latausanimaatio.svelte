// Tämä komponentti on ChatGpt:n luoma. Otin sen itse käyttöön App.sveltessä.

<script>
    import { fly } from "svelte/transition";
  </script>
  
  <div transition:fly={{ y: 20, duration: 500 }}>
    
    <!-- Animaatio näkyy, kun dataa ladataan API:sta -->
    <p>Ladataan hahmoja...</p>
  </div>
  
  <style>
    div {
      text-align: center;
      font-size: 18px;
      color: #a18c8c;
    }
  </style>