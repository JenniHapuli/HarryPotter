<script>
    export let hahmo; // Hahmon tiedot propsina
  </script>
  
  <div class="kortti">
    <!-- Näyttää hahmon kuvan, nimen ja tuvan (jos se on tiedossa) -->
    <img src={hahmo.image} alt={hahmo.name} />
    <h2>{hahmo.name}</h2>
    <p>{hahmo.house ? hahmo.house : "Ei kuulu mihinkään tupaan"}</p>
  </div>
  
  <style>
    .kortti {
      border-radius: 16px;
      padding: 10px;
      margin: 10px;
      text-align: center;
      width: 200px;
      background-color: #555c83;
      box-shadow: 0px 3px 2px 0px rgb(21, 0, 54);
      color: white;
    }
    img {
      width: 100%;
      border-radius: 8px;
    }
  </style>