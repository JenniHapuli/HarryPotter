<script>
  import { onMount } from "svelte";
  import Kortti from "./lib/Kortti.svelte";
  import Hakupalkki from "./lib/Hakupalkki.svelte";
  import Latausanimaatio from "./lib/Latausanimaatio.svelte";
  import Painike from "./lib/Painike.svelte";

  let hahmot = []; // Kaikki ladatut hahmot tallennetaan tänne
  let haetutHahmot = []; // Näytettävät hahmot suodattuvat tänne
  let lataa = false; // Tila datan latauksen näyttämiseksi, tämän teki ChatGpt.

  let sukupuoliSuodatus = ""; // Suodatus sukupuolen perusteella
  let tupaSuodatus = ""; // Suodatus tuvan perusteella
  let hakusana = ""; // Hakukenttä

  // Hakee hahmodatan API:sta ja tallentaa sen muuttujaan hahmot
  // ChatGpt auttoi käyttämään onMountia ja sen käyttöä
  onMount(async () => {
    lataa = true;
    const response = await fetch("https://hp-api.onrender.com/api/characters");
    hahmot = await response.json();
    haetutHahmot = hahmot; // Oletuksena näytetään kaikki hahmot
    lataa = false; // Tila datan latauksen näyttämiseksi, tämän teki ChatGpt.
  });

  // Suodattaa hahmot hakusanan, sukupuolen ja tuvan perusteella. 
  // ChatGpt auttoi selittämään funktiota minulle, jotta osaisin tehdä sen itse.
  function haeHahmot() {
    let suodatetutHahmot = hahmot;

    // Suodatetaan hahmot hakusanan perusteella (name)
    if (hakusana) {
      suodatetutHahmot = suodatetutHahmot.filter(hahmo =>
        hahmo.name.toLowerCase().includes(hakusana.toLowerCase()) // Haetaan vain hahmot, joiden nimi sisältää hakusanan
      );
    }

    // Suodatetaan hahmot sukupuolen perusteella, jos sukupuoli on valittu
    if (sukupuoliSuodatus) {
      suodatetutHahmot = suodatetutHahmot.filter(hahmo =>
        hahmo.gender === sukupuoliSuodatus
      );
    }

    // Suodatetaan hahmot tuvan perusteella, jos tupa on valittu (ja ei ole "any")
    if (tupaSuodatus && tupaSuodatus !== "any") {
      suodatetutHahmot = suodatetutHahmot.filter(hahmo =>
        hahmo.house === tupaSuodatus
      );
    }

    // Päivitetään näytettävät hahmot
    haetutHahmot = suodatetutHahmot;
  }

// Seuraavat 3 funktiota piti tehdä sen takia, ettei hakuehtojen valintajärjestyksellä
// olisi väliä. ChatGpt teki nämä 3 funktiota.
//Jostain syystä haku ei toimi ilman näitä:

  // 1. Päivitäsukupuolisuodatus ja hakee hahmot uudelleen
  function paivitaSukupuoliSuodatus(sukupuoli) {
    sukupuoliSuodatus = sukupuoli;
  }

  // 2. Päivitä tupasuodatus ja hakee hahmot uudelleen
  function paivitaTupaSuodatus(tupa) {
    tupaSuodatus = tupa;
  }

  // 3. Päivitä hakusanan ja hakee hahmot uudelleen
  function paivitaHakusana(event) {
    hakusana = event.target.value;
  }

  // Tämä funktio käsittelee hakusanan tapahtuman Hakupalkki-komponentista
  function hakuTapahtuma(event) {
    hakusana = event.detail;
    haeHahmot();
  }
</script>

<main>
  <h1>Harry Potter -hahmohaku</h1>

  <section class="hakutoiminnot">
    <!-- Hakukenttä -->
    <Hakupalkki on:haku={hakuTapahtuma} />

    <!-- Valintaruudut sukupuolen suodattamiseen -->
     <!-- on:change-funktio on ChatGpt:n tekemä lisäys inputteihin
      koska se teki myös niihin liittyvät päivitysfunktiot-->
    <div class="suodattimet">
      <p><strong>Sukupuoli: </strong></p>
      <label>
        <input type="radio" name="gender" value="" on:change={() => paivitaSukupuoliSuodatus("")} checked/> Kaikki
      </label>
      <label>
        <input type="radio" name="gender" value="female" on:change={() => paivitaSukupuoliSuodatus("female")} /> Naiset
      </label>
      <label>
        <input type="radio" name="gender" value="male" on:change={() => paivitaSukupuoliSuodatus("male")} /> Miehet
      </label>
    </div>

    <!-- Valintaruudut tuvan suodattamiseen -->
    <div class="suodattimet">
      <p><strong>Tupa: </strong></p>
      <label>
        <input type="radio" name="house" value="any" on:change={() => paivitaTupaSuodatus("any")} checked/> Mikä tahansa
      </label>
      <label>
        <input type="radio" name="house" value="Gryffindor" on:change={() => paivitaTupaSuodatus("Gryffindor")} /> Gryffindor
      </label>
      <label>
        <input type="radio" name="house" value="Hufflepuff" on:change={() => paivitaTupaSuodatus("Hufflepuff")} /> Hufflepuff
      </label>
      <label>
        <input type="radio" name="house" value="Ravenclaw" on:change={() => paivitaTupaSuodatus("Ravenclaw")} /> Ravenclaw
      </label>
      <label>
        <input type="radio" name="house" value="Slytherin" on:change={() => paivitaTupaSuodatus("Slytherin")} /> Slytherin
      </label>
    </div>

    <!-- "Hae"-painike, joka suorittaa haun -->
    <Painike teksti="Uusi haku" klikkaa={haeHahmot} />
  </section>

  <!-- Näyttää animaation, jos data on latauksessa. -->
  {#if lataa}
    <Latausanimaatio />
  {:else}
    <!-- Näyttää hahmokortit suodatettujen hahmojen perusteella -->
    <div class="kortit">
      {#each haetutHahmot as hahmo}
        <Kortti {hahmo} />
      {/each}
    </div>
  {/if}
</main>

<style>
  main {
    text-align: center;
    padding: 3em;
    background-color: #6e6f9b;
  }
  .suodattimet {
    display: flex;
    align-items: center;
    padding: 0.2em 1em 0.2em 1em;
  }
  label, p {
    margin: 0 10px;
    font-size: 20px;
  }
  
  .kortit {
  display: grid;
  /* ChatGpt auttoi tekemään korteista responsiiviset */
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  justify-items: center;
}

  .hakutoiminnot {
    background-color: #8c8ec3;
    padding: 1em 0.5em 0.5em 0.5em;
    margin-bottom: 1em;
    border-radius: 18px;
  }
</style>
